Here is the installation and initialization procedure of the PWA RUM template for React.js

# Contents of the pwa-rum-install-pack folder:
*You should have one copy of this ReadMe file,
an archive in .zip format and a .sh script


## WINDOWS USERS

#choice 1:
Git BASH
Git for Windows provides a BASH emulation used to run Git from the command line. *NIX users should feel right at home, as the BASH emulation behaves just like the "git" command in LINUX and UNIX environments.

https://www.atlassian.com/fr/git/tutorials/git-bash

https://gitforwindows.org/

after that, you can use the .sh file like linux user!


#choice 2:
Cmder is a software package created out of pure frustration over the absence of nice console emulators on Windows. It is based on amazing software, and spiced up with the Monokai color scheme and a custom prompt layout, looking sexy from the start.

https://cmder.net/

after that, you can use the .sh file like linux user!


## LINUX & MAC USERS

# How do we do it?
1 - Open your terminal in the folder you just unzipped!
2 - Drag the script into the terminal window you just opened...
3 - click on the terminal window to make it active then click on enter.
the installation starts!
4 - Then follow the steps of the script, and choose the options you want or not in your new app.

Enjoy!



#!/bin/bash
color='\e[96m' #cyan color
rose='\e[1;31m'
vertfonce='\e[0;32m'
orange='\e[0;33m'
bleuclair='\e[1;34m'
blanc='\e[1;37m'
BAR='##################################################'   # this is full bar, e.g. 50 chars

loader(){
  for i in {1..50}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep $1                # wait 100ms (.1 - slow velocity) or 10ms (.01 - false velocity) between "frames"
  done
echo ""                        # add a new line at the end
}

timer(){
    echo $SECONDS
}

# begin of  automatic install process
echo ""
echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 Hello $USER, The installation procedure will begin... \xf0\x9f\x98\xba\xf0\x9f\x98\x80${vertfonce}"
echo ""
# loader slow velocity
loader .1;
# Always start from current folder
cd ./
 echo -e "${color} unpacking the archive ${vertfonce}"
# loader slow velocity
loader .1;
SECONDS="0"
unzip cra-pwa-react-ultimate-messenger-jwt-integration.zip
# loader fast velocity
loader .01;
 echo -e "${color} unpacking successfully in $(timer) sec ${vertfonce}"
# loader fast velocity
loader .1;
# add a new line at the start of question
echo ""
# what name you want for your application
echo -e "${color} what name you want for your application \e[97m(my-example-name) ? ${blanc}"
read string
echo ""
echo -e "${color} Starting App creation... ${vertfonce}"
# loader fast velocity
loader .01;
SECONDS="0"
# create new react app with rum template from temporary folder
npx create-react-app ${string} --template file:./cra-pwa-react-ultimate-messenger-jwt-integration
echo ""
echo -e "${color} Installation completed in $(timer) sec! ${vertfonce}"
# loader fast velocity
loader .01;
echo ""
echo -e "${color} Deletion of the temporary folder necessary for the installation... ${vertfonce}"
SECONDS="0"
# loader slow velocity
loader .1;
#  remove temporary folder (packages)
rm -rf cra-pwa-react-ultimate-messenger-jwt-integration
echo ""
echo -e "${color} Temporary folder deleted in $(timer) sec! ${orange}"
echo ""                        # add a new line at the end
# loader fast velocity
loader .01;
echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 Your App: ${string}, is ready to work. Please wait a moment! \xf0\x9f\x98\xba\xf0\x9f\x98\x80 ${vertfonce}"
echo ""                        # add a new line at the end
echo -e "${color} Post installation Step: ${vertfonce}"
# loader slow velocity
loader .1;
cd ${string}/src/postInstallConfig
ls
 while true; do
    echo ""
    read -p " Do you want Admin panel to your App?" yn
    case $yn in
        [Yy]* ) echo -e "${color}App whith admin! Configuration in progress...${vertfonce}"; loader .1; break;; # else exit from script
        [Nn]* )  ex -sc '%s/true/false/|x' withAdmin.js
              echo -e "${color}You don't want admin panel, app whitout admin! Configuration in progress... ${vertfonce}"; loader .1; break;;
        * ) echo " Please answer Yes or No";;
    esac
done
echo ""
# loader fast velocity
loader .01;
 while true; do
    echo ""
    read -p " Do you want VideoChat to your App?" yn
    case $yn in
        [Yy]* ) echo -e "${color}App whith VideoChat! Configuration in progress...${vertfonce}"; loader .1; break;; # else exit from script
        [Nn]* )  ex -sc '%s/true/false/|x' withVideoChat.js
              echo -e "${color}You don't want VideoChat, app whitout VideoChat! Configuration in progress... ${vertfonce}"; loader .1; break;;
        * ) echo " Please answer Yes or No";;
    esac
done
echo ""
# loader fast velocity
loader .01;
while true; do
    echo ""
    read -p " Do you want Recoil use example in your App?" yn
    case $yn in
        [Yy]* ) echo -e "${color}App whith Recoil example! configuration in progress...${vertfonce}"; loader .1; break;; # else exit from script
        [Nn]* )  ex -sc '%s/true/false/|x' withRecoilExample.js
              echo -e "${color}You don't want Recoil example utilisation, app whitout example! configuration in progress... ${vertfonce}"; echo ""; loader .1; break;;
        * ) echo " Please answer Yes or No";;
    esac
done
echo ""
# loader fast velocity
loader .01;
while true; do
    echo ""
    read -p " Do you want classic bottom menu for mobile devices in your App?" yn
    case $yn in
        [Yy]* ) echo -e "${color}App whith bottom menu! configuration in progress...${vertfonce}"; loader .1; break;; # else exit from script
        [Nn]* )  ex -sc '%s/true/false/|x' withBottomMenu.js
                while true; do
                    echo ""
                    read -p " Do you want radial burger menu for mobile devices in your App?" yn
                    case $yn in
                        [Yy]* ) ex -sc '%s/false/true/|x' withRadialMenu.js; echo -e "${color}App whith radial burger menu! configuration in progress...${vertfonce}"; break;; # else exit from script
                        [Nn]* ) echo -e "${color}You don't want radial menu for your mobile app version, app whitout Bottom Menu! configuration in progress... ${vertfonce}"; echo ""; loader .1; break;;
                        * ) echo " Please answer Yes or No";;
                    esac
                done
                      echo -e "${color}Post configuration is done... Please wait! ${vertfonce}"; echo ""; loader .1; break;;
        * ) echo " Please answer Yes or No";;
    esac
done
loader .01;

cd ../..

ls
# loader fast velocity
loader .01;
# add a new line at the start of question
echo ""
# Init app section initAll script in package.json file
while true; do
    echo ""
    read -p " Do you wish to initialize the App right now?" yn
    case $yn in
        [Yy]* ) echo -e " App initialization... !"; npm run initAll; break;; # if yes -> go to the app folder & init all app
        [Nn]* ) echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 Many thanks for using the PWA RUM template version $USER \xf0\x9f\x98\xba\xf0\x9f\x98\x80${vertfonce}"; exit;; # else exit from script
        * ) echo " Please answer Yes or No";;
    esac
done
# loader slow velocity
loader .1;
# Editor section for automatic openning you app in VsCode
while true; do
    echo ""
    read -p " You have VsCode installed and you want to start working right now?" yn
    case $yn in
        [Yy]* ) echo -e " Opening you App in VsCode..."; code .; break;; # if yes -> that's open your app in vscode
        [Nn]* ) while true; do # else -> an another question
                    echo ""
                    read -p " Do you wish to start the App right now?" yn
                    case $yn in
                        [Yy]* ) echo -e " Starting App... !"; npm run dev; break;; # if yes -> start your app (back & front automaticly)
                        [Nn]* ) loader .01; ## loader fast velocity
                                echo ""
                                echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 Many thanks $USER for using the PWA RUM template version \xf0\x9f\x98\xba\xf0\x9f\x98\x80${vertfonce}"; exit;; # else -> thx and exit
                        * ) echo " Please answer Yes or No";;
                    esac
                done;;
        * ) echo " Please answer Yes or No";;
    esac
done
# loader slow velocity
loader .1;
# if your app is open to vsCode
echo ""
echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 Many thanks $USER for using the PWA RUM template version, you can work right now \xf0\x9f\x98\xba\xf0\x9f\x98\x80${vertfonce}"

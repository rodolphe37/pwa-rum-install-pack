Here is the installation and initialization procedure of the RUM template for React.js

# Contents of the pwa-rum-install-pack folder:
*You should have next to this ReadMe file you are reading,
an archive in .zip format and a .sh script

# How do we do it?
1 - Open your terminal in the folder you just unzipped!
2 - Drag the script into the terminal window you just opened...
3 - click on the terminal window to make it active then click on enter.
the installation starts!
4 - Then follow the steps of the script, and choose the options you want or not in your new app.

Enjoy!

